namespace Sample; public class Widget { }
